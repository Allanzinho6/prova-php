<?php 
	
	//echo $_POST['username'];
	//echo $_POST['email'];
	include_once('config/conn.php');
		
		$titulo = $_POST['título'];
		$descricao = $_POST['descrição'];

		//método prepare

	$stmt = $connect->prepare("INSERT INTO posts (inserir,título,descricao) VALUES(:inserir, :título, :descrição)");
			
			//método bindParam - ligar o parâmetro com o valor

	$stmt->bindParam(':NOME', $nome);
	$stmt->bindParam(':título', $titulo);
	$stmt->bindParam(':descrição', $descricao);
	$stmt->execute();
	
	?>
