<?php

include "config/conn.php";

$id = 1;



//preparar
$stmt = $connect->prepare("INSERT INTO posts (TÍTULO,DESCRIÇÃO) VALUES( :TÍTULO, :DESCRIÇÃO)");
//trocar
$stmt-> bindParam(":ID", $id);
$stmt-> bindParam(":TÍTULO", $titulo);
$stmt-> bindParam(":DESCRIÇÃO", $descricao);


//executar
$stmt-> execute();

//echo "Atualizado com sucesso";

?>