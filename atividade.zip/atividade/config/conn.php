<?php 
	
	$host = 'localhost';
	$user = 'root';
	$password = "";
	$dbname = "posts";

	try{
		$connect = new PDO("mysql:host=" .$host."; dbname=".$dbname, $user, $password);

		//echo "Conexão realizada com sucesso!";
	}catch(Exception $err){
			//echo "Erro na Conexão";
	}
 ?>