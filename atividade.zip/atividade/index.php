<!DOCTYPE html>
<html>
<head>
	<title>Formulário</title>
</head>
<body>
	<form action="atualizar.php" method="posts">
		<label>Inserir</label>
		<br>

		<label>Título</label>
		<div><input type="text"  value=""></div>
		<label>Descrição</label>
		<div><input type="text" name="" value=""></div>
		<div><input type="submit" value="Enviar"></div>
	</form>

</body>
</html>